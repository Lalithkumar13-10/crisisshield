import { useState, useEffect } from "react";
import { Shield, Navigation, Activity } from "lucide-react";
import SOSButton from "../components/SOSButton";
import EmergencyChat from "../components/EmergencyChat";
import { Alert, UserProfile } from "../types";
import { api } from "../services/api";

export default function GuestDashboard({ user, onLogout }: { user: UserProfile; onLogout: () => void }) {
  const [activeAlert, setActiveAlert] = useState<Alert | null>(null);
  const [meshNodes] = useState(24);

  useEffect(() => {
    const fetchAlerts = async () => {
      try {
        const list = await api.alerts.list({ 
          hotelId: user.hotelId, 
          status: "active" 
        });
        if (list.length > 0) {
          setActiveAlert(list[0]);
        } else {
          setActiveAlert(null);
        }
      } catch (err) {
        console.error("Alerts sync error:", err);
      }
    };

    fetchAlerts();
    const interval = setInterval(fetchAlerts, 5000);
    return () => clearInterval(interval);
  }, [user.hotelId]);

  return (
    <div className="min-h-screen bg-slate-950 flex h-screen w-full overflow-hidden text-slate-200">
      {/* Side Navigation */}
      <aside className="w-64 border-r border-slate-800 bg-slate-900 flex flex-col hidden lg:flex">
        <div className="p-8 border-b border-slate-800">
          <div className="flex items-center gap-2 text-red-500 font-black text-2xl uppercase tracking-tighter italic">
            <Shield className="w-7 h-7" /> CrisisShield
          </div>
          <div className="text-[10px] text-slate-500 mt-1 uppercase font-bold tracking-[0.2em] leading-none">Guest Operations</div>
        </div>
        
        <nav className="flex-1 p-6 space-y-2">
          <div className="bg-slate-800 text-white p-4 rounded-2xl border border-slate-700 flex items-center gap-3">
             <Activity className="w-5 h-5 text-blue-400" />
             <span className="text-xs font-bold uppercase tracking-widest leading-none">Security Deck</span>
          </div>
          <p className="px-4 py-2 text-[10px] text-slate-500 font-bold uppercase tracking-widest mt-10">Protocols</p>
          <div className="p-4 rounded-2xl text-slate-500 flex items-center gap-3 hover:bg-slate-800 transition-all cursor-pointer">
             <Navigation className="w-5 h-5" />
             <span className="text-xs font-bold uppercase tracking-widest leading-none">Evacuation</span>
          </div>
        </nav>

        <div className="p-6 border-t border-slate-800 bg-slate-950/50">
          <div className="flex items-center gap-3 mb-4">
            <div className="w-10 h-10 rounded-xl bg-slate-800 border border-slate-700 flex items-center justify-center text-xs font-black">
              {user.name.slice(0, 2).toUpperCase()}
            </div>
            <div>
              <div className="text-xs font-black uppercase tracking-tight text-white">{user.name}</div>
              <div className="text-[8px] text-slate-500 font-bold uppercase tracking-widest">ID: {user.uid.slice(-6)}</div>
            </div>
          </div>
          <button 
            onClick={onLogout}
            className="w-full bg-slate-800 hover:bg-red-900/40 hover:text-red-400 border border-slate-700 py-3 rounded-xl font-bold text-[10px] transition-all uppercase tracking-widest"
          >
            Terminal Exit
          </button>
        </div>
      </aside>

      <main className="flex-1 flex flex-col relative overflow-hidden bg-[radial-gradient(#1e293b_1px,transparent_1px)] [background-size:32px_32px]">
        {/* Header Ribbon */}
        <header className="h-16 border-b border-slate-800 flex items-center justify-between px-8 bg-slate-900/50 backdrop-blur-xl">
          <div className="flex items-center gap-8">
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${activeAlert ? 'bg-red-500 animate-pulse' : 'bg-emerald-500'}`}></span>
              <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400">
                MESH: ONLINE ({meshNodes} NODES)
              </span>
            </div>
            <div className="flex items-center gap-2">
              <span className={`w-2 h-2 rounded-full ${activeAlert ? 'bg-red-500 animate-pulse' : 'bg-slate-700'}`}></span>
              <span className="text-[10px] uppercase font-bold tracking-widest text-slate-400">
                ALERTS: {activeAlert ? "01 CRITICAL" : "00 ACTIVE"}
              </span>
            </div>
          </div>
          <div className="flex items-center gap-4 text-[10px] font-mono font-bold text-slate-500 uppercase tracking-widest">
            <div className="px-3 py-1 bg-slate-800 border border-slate-700 rounded text-slate-300">WING ALPHA - LVL 04</div>
            <div>{new Date().toLocaleTimeString()} UTC</div>
          </div>
        </header>

        <div className="flex-1 flex overflow-hidden">
          {/* Main Map/Evacuation Area */}
          <div className="flex-1 p-8 flex flex-col gap-6 overflow-y-auto">
            <div className="flex-1 bg-slate-900 border border-slate-800 rounded-3xl p-6 relative flex flex-col min-h-[400px]">
               <div className="absolute top-6 left-6 bg-slate-950/80 backdrop-blur border border-slate-800 p-2 rounded text-[10px] text-slate-400 z-10 font-mono tracking-widest uppercase">
                 LVL 04 - SECURE EVACUATION OVERLAY
               </div>
               
               <div className="flex-1 border border-slate-800/50 rounded-2xl relative overflow-hidden bg-slate-950/50 flex items-center justify-center">
                 <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px]"></div>
                 
                 {/* CSS Floorplan Simulation */}
                 <svg viewBox="0 0 800 500" className="w-full h-full max-w-2xl text-slate-800 font-mono">
                   <rect x="50" y="50" width="700" height="400" fill="none" stroke="currentColor" strokeWidth="2" className="opacity-30"/>
                   {/* Vertical Lines */}
                   <path d="M200 50v400M400 50v400M600 50v400" stroke="currentColor" strokeWidth="1" className="opacity-20"/>
                   {/* Horizontal Corridors */}
                   <path d="M50 250h700" stroke="currentColor" strokeWidth="1" className="opacity-20"/>
                   
                   {/* Room Labels */}
                   <text x="125" y="150" fill="currentColor" fontSize="12" textAnchor="middle" className="font-black opacity-40">ROOM 401</text>
                   <text x="300" y="150" fill="currentColor" fontSize="12" textAnchor="middle" className="font-black opacity-40">ROOM 402</text>
                   <text x="500" y="150" fill="currentColor" fontSize="12" textAnchor="middle" className="font-black opacity-40">ROOM 403</text>
                   <text x="675" y="150" fill="currentColor" fontSize="12" textAnchor="middle" className="font-black opacity-40">ROOM 404</text>
                   
                   <text x="125" y="350" fill="currentColor" fontSize="12" textAnchor="middle" className="font-black opacity-40">ROOM 405</text>
                   <text x="300" y="350" fill="currentColor" fontSize="12" textAnchor="middle" className="font-black opacity-40">ROOM 406</text>
                   <text x="500" y="350" fill="currentColor" fontSize="12" textAnchor="middle" className="font-black opacity-40">ROOM 407</text>
                   <text x="675" y="350" fill="currentColor" fontSize="12" textAnchor="middle" className="font-black opacity-40">ROOM 408</text>

                   {activeAlert && (
                     <>
                       {/* Secure Path */}
                       <path d="M200 150 L200 250 L500 250" stroke="#3b82f6" strokeWidth="4" strokeDasharray="8 4" fill="none" className="animate-pulse shadow-glow"/>
                       {/* Danger Zone */}
                       <circle cx="400" cy="250" r="24" fill="#ef4444" className="animate-ping opacity-10"/>
                       <circle cx="400" cy="250" r="12" fill="#ef4444" className="opacity-30 animate-pulse"/>
                       <circle cx="400" cy="250" r="6" fill="#ef4444" className="status-glow-red"/>
                       
                       <text x="400" y="285" fill="#ef4444" fontSize="10" textAnchor="middle" className="font-black uppercase tracking-widest animate-pulse">
                         INCIDENT SITE: LVL 04-B
                       </text>
                     </>
                   )}
                 </svg>

                 {activeAlert && (
                   <div className="absolute bottom-6 left-6 right-6 bg-red-600/20 backdrop-blur-xl border border-red-500/30 p-4 rounded-2xl flex items-center gap-4">
                      <div className="w-12 h-12 bg-red-600 rounded-xl flex items-center justify-center text-white status-glow-red">
                        <Navigation className="w-7 h-7" />
                      </div>
                      <div>
                        <p className="text-sm font-black uppercase tracking-tighter text-white">Emergency: {activeAlert.type}</p>
                        <p className="text-xs text-red-100/70 font-medium uppercase tracking-widest leading-none mt-1">Exit Wing A Immediately</p>
                      </div>
                   </div>
                 )}
               </div>
            </div>

            {/* Bottom Controls */}
            <div className="h-48 flex gap-6">
              <div className="w-2/3 bg-slate-900 border border-slate-800 rounded-3xl p-6 flex flex-col">
                <div className="text-[10px] text-slate-500 font-black uppercase tracking-[0.2em] mb-4">Tactical Comms</div>
                <div className="bg-blue-600/10 border border-blue-500/20 rounded-2xl p-4 flex-1 italic text-sm text-slate-400 leading-relaxed font-medium">
                   "Alert Detected: Instructions pushed to mobile terminals. Evacuation Route 4A optimized for minimum smoke exposure."
                </div>
              </div>
              <div className="w-1/3 flex flex-col justify-center items-center bg-slate-900 border border-slate-800 rounded-3xl">
                 <SOSButton hotelId={user.hotelId} userUid={user.uid} />
              </div>
            </div>
          </div>

          {/* Right Sidebar - Chat */}
          <aside className="w-96 border-l border-slate-800 bg-slate-900/30 p-8 hidden xl:flex flex-col gap-6">
            <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">AI Support Terminal</h3>
            <div className="flex-1 overflow-hidden rounded-[32px] border border-slate-800">
               <EmergencyChat emergencyType={activeAlert?.type || "none"} />
            </div>
          </aside>
        </div>

        {/* Global Footer Status */}
        <footer className="h-10 border-t border-slate-800 bg-slate-950 flex items-center px-8 text-[9px] font-mono font-bold uppercase tracking-[0.3em] text-slate-600 justify-between">
          <div>NODE ID: GPH-{user.uid.slice(0, 4)} | SECURE PROTOCOL LAYER 7</div>
          <div className="flex gap-8">
            <span>AZIMUTH: 184.2</span>
            <span>SYSTEM STABLE</span>
          </div>
        </footer>
      </main>
    </div>
  );
}

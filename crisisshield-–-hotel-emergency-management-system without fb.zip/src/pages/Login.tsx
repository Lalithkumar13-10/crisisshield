import { useState } from "react";
import { Shield, Mail, Lock, UserPlus, AlertCircle, LogIn, UserCircle } from "lucide-react";
import { api } from "../services/api";

export default function Login() {
  const [loading, setLoading] = useState(false);
  const [role, setRole] = useState<"guest" | "staff" | "admin">("guest");
  const [mode, setMode] = useState<"login" | "register">("login");
  const [email, setEmail] = useState("");
  const [password, setPassword] = useState("");
  const [name, setName] = useState("");
  const [error, setError] = useState<string | null>(null);

  const handleAuth = async (e: React.FormEvent) => {
    e.preventDefault();
    setLoading(true);
    setError(null);
    try {
      let user;
      if (mode === "login") {
        user = await api.auth.login({ email, password });
      } else {
        user = await api.auth.register({
          email,
          password,
          name: name || "New User",
          role
        });
      }
      localStorage.setItem("cs_uid", user.uid);
    } catch (err: any) {
      setError(err.message || "Authentication failed. Node unreachable.");
    } finally {
      setLoading(false);
    }
  };

  const handleBypass = () => {
    setEmail("admin@example.com");
    setPassword("admin123");
    setMode("login");
  };

  return (
    <div className="min-h-screen bg-slate-950 flex items-center justify-center p-4 relative overflow-hidden">
      <div className="absolute top-0 left-0 w-full h-full opacity-20 pointer-events-none">
        <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-blue-900 rounded-full blur-[160px]"></div>
        <div className="absolute bottom-1/4 right-1/4 w-[500px] h-[500px] bg-red-900/50 rounded-full blur-[160px]"></div>
      </div>

      <div className="max-w-md w-full bg-slate-900/40 backdrop-blur-3xl p-10 rounded-[32px] border border-slate-800 shadow-2xl relative z-10">
        <div className="flex flex-col items-center mb-10 text-center">
          <div className="w-20 h-20 bg-gradient-to-br from-blue-600 to-slate-900 rounded-3xl flex items-center justify-center mb-6 shadow-2xl shadow-blue-500/20 status-glow-red border border-white/10">
            <Shield className="w-12 h-12 text-white" />
          </div>
          <h1 className="text-4xl font-black text-white tracking-tighter uppercase italic">CrisisShield</h1>
          <p className="text-slate-400 text-sm mt-2 font-mono uppercase tracking-[0.2em]">Safety Operations Terminal</p>
        </div>

        {error && (
          <div className="bg-red-500/10 border border-red-500/30 p-4 rounded-xl flex items-center gap-3 mb-6 animate-in fade-in slide-in-from-top-2">
            <AlertCircle className="w-5 h-5 text-red-500 shrink-0" />
            <p className="text-xs text-red-400 font-medium">{error}</p>
          </div>
        )}

        <div className="space-y-4">
          <form onSubmit={handleAuth} className="space-y-4">
          <div className="bg-slate-900/50 border border-slate-800 rounded-2xl p-1 flex mb-6">
            <button 
              type="button"
              onClick={() => setMode("login")}
              className={`flex-1 py-2 text-xs font-bold uppercase tracking-widest rounded-xl transition-all ${mode === "login" ? "bg-slate-800 text-white shadow-lg" : "text-slate-500"}`}
            >
              Secure Login
            </button>
            <button 
              type="button"
              onClick={() => setMode("register")}
              className={`flex-1 py-2 text-xs font-bold uppercase tracking-widest rounded-xl transition-all ${mode === "register" ? "bg-slate-800 text-white shadow-lg" : "text-slate-500"}`}
            >
              Request Key
            </button>
          </div>

          {mode === "register" && (
            <div className="relative group">
              <UserCircle className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-blue-500 transition-colors" />
              <input 
                type="text" 
                placeholder="Full Legal Name" 
                value={name}
                onChange={e => setName(e.target.value)}
                autoComplete="name"
                className="w-full bg-slate-950/50 border border-slate-800 text-white p-4 pl-12 rounded-2xl focus:ring-4 focus:ring-blue-500/10 outline-none transition-all placeholder:text-slate-700" 
                required
              />
            </div>
          )}

          <div className="relative group">
            <Mail className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-blue-500 transition-colors" />
            <input 
              type="email" 
              placeholder="Operational Email" 
              value={email}
              onChange={e => setEmail(e.target.value)}
              autoComplete="email"
              className="w-full bg-slate-950/50 border border-slate-800 text-white p-4 pl-12 rounded-2xl focus:ring-4 focus:ring-blue-500/10 outline-none transition-all placeholder:text-slate-700" 
              required
            />
          </div>

          <div className="relative group">
            <Lock className="absolute left-4 top-1/2 -translate-y-1/2 w-5 h-5 text-slate-500 group-focus-within:text-blue-500 transition-colors" />
            <input 
              type="password" 
              placeholder="Access Password" 
              value={password}
              onChange={e => setPassword(e.target.value)}
              autoComplete="current-password"
              className="w-full bg-slate-950/50 border border-slate-800 text-white p-4 pl-12 rounded-2xl focus:ring-4 focus:ring-blue-500/10 outline-none transition-all placeholder:text-slate-700" 
              required
            />
          </div>

          <div className="grid grid-cols-3 gap-2 py-4">
            {(["guest", "staff", "admin"] as const).map(r => (
              <button
                key={r}
                type="button"
                onClick={() => setRole(r)}
                className={`py-3 rounded-xl border text-[10px] font-black uppercase tracking-widest transition-all ${
                  role === r ? "bg-blue-600 border-blue-500 text-white shadow-xl shadow-blue-500/20" : "bg-slate-950 border-slate-800 text-slate-500 hover:border-slate-700"
                }`}
              >
                {r}
              </button>
            ))}
          </div>

          <button
            type="submit"
            disabled={loading}
            className="w-full bg-white text-slate-950 font-black py-4 rounded-2xl flex items-center justify-center gap-3 transition-all hover:scale-[1.02] active:scale-95 disabled:opacity-50 uppercase tracking-[0.2em] shadow-lg shadow-white/5"
          >
            {loading ? (
              <div className="w-5 h-5 border-2 border-slate-950/30 border-t-slate-950 rounded-full animate-spin"></div>
            ) : (
              <>
                {mode === "login" ? <LogIn className="w-5 h-5" /> : <UserPlus className="w-5 h-5" />}
                {mode === "login" ? "Initialize Deck" : "Submit Request"}
              </>
            )}
          </button>
        </form>

        <div className="mt-10 flex items-center gap-4 text-slate-700">
          <div className="flex-1 h-px bg-slate-800"></div>
          <span className="text-[10px] font-black uppercase tracking-widest">Admin Access</span>
          <div className="flex-1 h-px bg-slate-800"></div>
        </div>

        <button
          onClick={handleBypass}
          type="button"
          className="w-full mt-6 bg-slate-900 hover:bg-slate-800 text-white font-bold py-4 rounded-2xl flex items-center justify-center gap-3 border border-slate-800 transition-all active:scale-95 text-sm"
        >
          <Lock className="w-5 h-5 text-amber-500" />
          Secure Admin Override
        </button>
        </div>

        <p className="mt-10 text-center text-[10px] text-slate-600 font-mono tracking-widest leading-relaxed uppercase">
          {mode === "register" ? "New keys require level 4 administrator clearance. Wait time: 5-10m." : "Authorized personnel only. Misuse is strictly monitored."}
        </p>
      </div>
    </div>
  );
}

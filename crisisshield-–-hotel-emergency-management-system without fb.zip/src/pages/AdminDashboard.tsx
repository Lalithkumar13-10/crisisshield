import { useState, useEffect } from "react";
import { Shield, Building, Plus, MapPin, Activity, ChevronRight, Users, CheckCircle, XCircle, Lock } from "lucide-react";
import { Hotel, UserProfile } from "../types";
import { api } from "../services/api";

export default function AdminDashboard({ user, onLogout }: { user: UserProfile; onLogout: () => void }) {
  const [hotels, setHotels] = useState<Hotel[]>([]);
  const [pendingUsers, setPendingUsers] = useState<UserProfile[]>([]);
  const [newHotel, setNewHotel] = useState({ name: "", address: "", lat: 12.9716, lng: 77.5946 });
  const [showAdd, setShowAdd] = useState(false);
  const [tab, setTab] = useState<"hotels" | "users">("hotels");

  useEffect(() => {
    const fetchData = async () => {
      try {
        const hList = await api.hotels.list();
        setHotels(hList);
        const uList = await api.users.listPending();
        setPendingUsers(uList);
      } catch (err) {
        console.error("Data sync error:", err);
      }
    };

    fetchData();
    const interval = setInterval(fetchData, 5000);
    return () => clearInterval(interval);
  }, []);

  const handleAddHotel = async () => {
    if (!newHotel.name) return;
    try {
      await api.hotels.create({
        name: newHotel.name,
        address: newHotel.address,
        location: { lat: newHotel.lat, lng: newHotel.lng }
      });
      setShowAdd(false);
      setNewHotel({ name: "", address: "", lat: 12.9716, lng: 77.5946 });
      const hList = await api.hotels.list();
      setHotels(hList);
    } catch (err) {
      console.error("Error adding hotel:", err);
    }
  };

  const approveUser = async (uid: string) => {
    try {
      await api.users.approve(uid);
      setPendingUsers(prev => prev.filter(u => u.uid !== uid));
    } catch (err) {
      console.error("Error approving user:", err);
    }
  };

  const rejectUser = async (uid: string) => {
    try {
      await api.users.reject(uid);
      setPendingUsers(prev => prev.filter(u => u.uid !== uid));
    } catch (err) {
      console.error("Error rejecting user:", err);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex flex-col font-sans">
      <header className="bg-slate-900 border-b border-slate-800 px-8 py-4 text-white flex items-center justify-between sticky top-0 z-30">
        <div className="flex items-center gap-4">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center status-glow-red">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <div>
            <h1 className="text-xl font-black tracking-tighter uppercase italic">CrisisShield Admin</h1>
            <p className="text-[10px] font-mono text-slate-500 uppercase tracking-widest">Global Control Surface</p>
          </div>
        </div>
        
        <div className="flex items-center gap-4">
          <div className="hidden lg:flex items-center gap-6 mr-6">
            <div className="flex flex-col items-end">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">System Health</span>
              <span className="text-xs font-bold text-emerald-500 flex items-center gap-1">
                <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span>
                Nominal
              </span>
            </div>
            <div className="flex flex-col items-end">
              <span className="text-[10px] font-black text-slate-500 uppercase tracking-widest">Global Alerts</span>
              <span className="text-xs font-bold text-slate-300">Active Monitoring</span>
            </div>
          </div>
          <button 
            onClick={onLogout}
            className="px-4 py-2 border border-slate-700 bg-slate-800 hover:bg-slate-700 rounded-xl text-[10px] font-black uppercase tracking-widest transition-all"
          >
            Terminal Logout
          </button>
        </div>
      </header>

      <div className="flex flex-1">
        {/* Navigation Sidebar */}
        <aside className="w-64 bg-slate-900/50 border-r border-slate-800 p-6 flex flex-col gap-2">
          <button 
            onClick={() => setTab("hotels")}
            className={`w-full p-4 rounded-2xl flex items-center gap-4 transition-all ${tab === "hotels" ? "bg-blue-600 text-white shadow-xl shadow-blue-600/20" : "text-slate-400 hover:bg-slate-800"}`}
          >
            <Building className="w-5 h-5" />
            <span className="text-sm font-bold uppercase tracking-tight">Hotel Directory</span>
          </button>
          <button 
            onClick={() => setTab("users")}
            className={`w-full p-4 rounded-2xl flex items-center gap-4 transition-all relative ${tab === "users" ? "bg-blue-600 text-white shadow-xl shadow-blue-600/20" : "text-slate-400 hover:bg-slate-800"}`}
          >
            <Users className="w-5 h-5" />
            <span className="text-sm font-bold uppercase tracking-tight">User Clearance</span>
            {pendingUsers.length > 0 && (
              <span className="absolute top-3 right-3 w-5 h-5 bg-red-500 text-white text-[10px] flex items-center justify-center rounded-full font-black animate-pulse">
                {pendingUsers.length}
              </span>
            )}
          </button>
        </aside>

        <main className="flex-1 p-8">
          {tab === "hotels" ? (
            <div className="animate-in fade-in duration-500">
              <div className="flex items-center justify-between mb-10">
                <div>
                  <h2 className="text-3xl font-black text-white tracking-tighter uppercase mb-1 italic">Hotel Assets</h2>
                  <p className="text-slate-500 text-sm font-medium">Monitoring {hotels.length} active global properties</p>
                </div>
                <button 
                  onClick={() => setShowAdd(!showAdd)}
                  className="bg-white text-slate-950 px-6 py-4 rounded-2xl font-black uppercase text-xs tracking-widest flex items-center gap-3 hover:scale-105 active:scale-95 transition-all shadow-xl shadow-white/5"
                >
                  <Plus className="w-5 h-5" /> Provision New Asset
                </button>
              </div>

              {showAdd && (
                <div className="mb-10 bg-slate-900 border border-slate-800 p-8 rounded-[32px] shadow-2xl flex flex-col lg:flex-row gap-8 animate-in slide-in-from-top-4">
                  <div className="flex-1 space-y-6">
                    <div>
                      <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest block mb-1">Hotel Identity</label>
                      <input 
                        className="w-full bg-slate-950 border border-slate-800 p-4 rounded-2xl text-white outline-none focus:border-blue-500 transition-all font-bold placeholder:text-slate-800" 
                        placeholder="Grand Safety Gateway"
                        value={newHotel.name}
                        onChange={e => setNewHotel({...newHotel, name: e.target.value})}
                      />
                    </div>
                    <div>
                      <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest block mb-1">Global Address</label>
                      <input 
                        className="w-full bg-slate-950 border border-slate-800 p-4 rounded-2xl text-white outline-none focus:border-blue-500 transition-all font-bold placeholder:text-slate-800" 
                        placeholder="123 Vector Plaza, Silicon Valley"
                        value={newHotel.address}
                        onChange={e => setNewHotel({...newHotel, address: e.target.value})}
                      />
                    </div>
                  </div>
                  <div className="flex-1 space-y-6 flex flex-col">
                    <div className="grid grid-cols-2 gap-4">
                      <div>
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest block mb-1">Coordinate Latitude</label>
                        <input 
                          type="number"
                          className="w-full bg-slate-950 border border-slate-800 p-3 rounded-2xl text-white outline-none focus:border-blue-500 transition-all font-mono" 
                          value={newHotel.lat}
                          onChange={e => setNewHotel({...newHotel, lat: parseFloat(e.target.value)})}
                        />
                      </div>
                      <div>
                        <label className="text-[10px] font-black text-slate-500 uppercase tracking-widest block mb-1">Coordinate Longitude</label>
                        <input 
                          type="number"
                          className="w-full bg-slate-950 border border-slate-800 p-3 rounded-2xl text-white outline-none focus:border-blue-500 transition-all font-mono" 
                          value={newHotel.lng}
                          onChange={e => setNewHotel({...newHotel, lng: parseFloat(e.target.value)})}
                        />
                      </div>
                    </div>
                    <div className="mt-auto">
                      <button 
                        onClick={handleAddHotel}
                        className="w-full bg-blue-600 font-black py-5 rounded-2xl text-white uppercase tracking-[0.2em] shadow-lg shadow-blue-500/20 active:scale-95 transition-all text-xs"
                      >
                        Execute Deployment Protocol
                      </button>
                    </div>
                  </div>
                </div>
              )}

              <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
                {hotels.map(hotel => (
                  <div key={hotel.id} className="bg-slate-900 border border-slate-800/50 p-6 rounded-[32px] group hover:border-blue-500/50 transition-all shadow-lg hover:shadow-blue-500/10">
                    <div className="flex items-start justify-between mb-6">
                      <div className="w-14 h-14 bg-slate-950 rounded-2xl flex items-center justify-center text-slate-700 group-hover:bg-blue-600 group-hover:text-white transition-all">
                        <Building className="w-7 h-7" />
                      </div>
                      <span className="text-[10px] font-mono bg-black/40 text-slate-500 px-3 py-1 rounded-full uppercase">ID: {hotel.id.slice(-6)}</span>
                    </div>
                    <h3 className="text-xl font-black text-white uppercase tracking-tight mb-2 italic">{hotel.name}</h3>
                    <p className="text-xs text-slate-500 mb-6 flex items-center gap-2">
                       <MapPin className="w-3 h-3" /> {hotel.address}
                    </p>
                    <div className="flex items-center justify-between pt-6 border-t border-white/5 mt-auto">
                      <div className="flex gap-1.5">
                        <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
                        <div className="w-1.5 h-1.5 bg-emerald-500 rounded-full"></div>
                        <div className="w-1.5 h-1.5 bg-slate-700 rounded-full"></div>
                      </div>
                      <button className="flex items-center gap-1 text-[10px] font-black uppercase tracking-widest text-blue-500 hover:gap-2 transition-all">
                        OPERATIONS MAP <ChevronRight className="w-4 h-4" />
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ) : (
            <div className="animate-in fade-in duration-500">
              <div className="mb-10">
                <h2 className="text-3xl font-black text-white tracking-tighter uppercase mb-1 italic">Clearance Requests</h2>
                <p className="text-slate-500 text-sm font-medium">Administrative authorization queue for staff and admin roles</p>
              </div>

              {pendingUsers.length === 0 ? (
                <div className="bg-slate-900/50 border border-dashed border-slate-800 rounded-[32px] p-20 flex flex-col items-center text-center">
                   <div className="w-20 h-20 bg-slate-900 border border-slate-800 rounded-3xl flex items-center justify-center text-slate-700 mb-6">
                     <Lock className="w-10 h-10" />
                   </div>
                   <h3 className="text-white font-bold text-lg uppercase tracking-tight mb-2">Queue Empty</h3>
                   <p className="text-slate-500 text-sm max-w-xs uppercase font-mono tracking-widest text-[10px]">All clearance requests have been processed. Systems are secure.</p>
                </div>
              ) : (
                <div className="space-y-4">
                  {pendingUsers.map(u => (
                    <div key={u.uid} className="bg-slate-900 border border-slate-800 p-6 rounded-[32px] flex flex-col md:flex-row items-center justify-between gap-6 transition-all hover:bg-slate-900/80">
                      <div className="flex items-center gap-6">
                        <div className={`w-14 h-14 rounded-2xl flex items-center justify-center bg-slate-950 status-glow-red border border-white/5`}>
                          <Users className="w-7 h-7 text-slate-400" />
                        </div>
                        <div>
                          <div className="flex items-center gap-3 mb-1">
                            <h3 className="text-xl font-black text-white uppercase tracking-tight">{u.name}</h3>
                            <span className="text-[10px] font-black bg-blue-600 px-2 py-0.5 rounded-md text-white uppercase">{u.role}</span>
                          </div>
                          <p className="text-xs font-mono text-slate-500 uppercase tracking-widest">{u.email}</p>
                        </div>
                      </div>

                      <div className="flex items-center gap-4">
                        <button 
                          onClick={() => rejectUser(u.uid)}
                          className="flex items-center gap-2 text-red-500 hover:text-red-400 bg-red-500/10 hover:bg-red-500/20 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-red-500/30 transition-all"
                        >
                          <XCircle className="w-4 h-4" /> Deny Access
                        </button>
                        <button 
                          onClick={() => approveUser(u.uid)}
                          className="flex items-center gap-2 text-emerald-500 hover:text-emerald-400 bg-emerald-500/10 hover:bg-emerald-500/20 px-6 py-3 rounded-2xl text-[10px] font-black uppercase tracking-widest border border-emerald-500/30 transition-all"
                        >
                          <CheckCircle className="w-4 h-4" /> Grant Clearance
                        </button>
                      </div>
                    </div>
                  ))}
                </div>
              )}
            </div>
          )}
        </main>
      </div>

      <footer className="bg-slate-950 border-t border-slate-900 h-12 flex items-center justify-between px-8 text-[10px] font-mono uppercase tracking-[0.3em] text-slate-700">
        <div>CRYSI-OS V4.2.1 | GLOBAL HUB NODE: 121</div>
        <div className="flex gap-8">
           <span>ENCRYPTION: AES-256</span>
           <span>LAT: 12.97 N | LNG: 77.59 E</span>
        </div>
      </footer>
    </div>
  );
}

import { useState, useEffect } from "react";
import { 
  Shield, AlertTriangle, Users, Map as MapIcon, 
  LogOut, Activity, Flame, Wind, 
  Camera, Bell, CheckCircle
} from "lucide-react";
import { Alert, UserProfile, Hotel } from "../types";
import { analyzeCameraData } from "../services/aiService";
import { api } from "../services/api";

export default function StaffDashboard({ user, onLogout }: { user: UserProfile; onLogout: () => void }) {
  const [activeAlerts, setActiveAlerts] = useState<Alert[]>([]);
  const [hotel, setHotel] = useState<Hotel | null>(null);
  const [isAlerting, setIsAlerting] = useState(false);
  const [newAlertType, setNewAlertType] = useState<Alert["type"]>("fire");

  useEffect(() => {
    // Hotel info
    api.hotels.get(user.hotelId)
      .then(setHotel)
      .catch(err => console.error("Hotel sync error:", err));

    // Active Alerts Polling
    const fetchAlerts = async () => {
      try {
        const list = await api.alerts.list({ 
          hotelId: user.hotelId, 
          status: "active" 
        });
        setActiveAlerts(list);
      } catch (err) {
        console.error("Alerts sync error:", err);
      }
    };

    fetchAlerts();
    const interval = setInterval(fetchAlerts, 5000);
    return () => clearInterval(interval);
  }, [user.hotelId]);

  const triggerAlert = async () => {
    setIsAlerting(true);
    try {
      await api.alerts.create({
        hotelId: user.hotelId,
        type: newAlertType,
        status: "active",
        severity: "critical",
        description: `Manual ${newAlertType} trigger by Staff: ${user.name}`,
        location: { floor: 2, room: "Hallway B", lat: 12.9716, lng: 77.5946 },
        reporterId: user.uid
      });
    } catch (err) {
      console.error("Trigger alert error:", err);
    }
    setTimeout(() => setIsAlerting(false), 2000);
  };

  const resolveAlert = async (id: string) => {
    try {
      await api.alerts.update(id, { status: "resolved" });
      setActiveAlerts(prev => prev.filter(a => a.id !== id));
    } catch (err) {
      console.error("Resolve alert error:", err);
    }
  };

  const analyzeCam = async () => {
    try {
      const data = await analyzeCameraData(
        { location: "Main Lobby", movement: "active", density: "high", blocked: "false" },
        user.hotelId
      );
      alert(`AI ANALYSIS RESULT:\nDensity: ${data.density}\nBlocked Exits: ${data.blockedExits}\nPath: ${data.evacuationPathRecommendation}`);
    } catch (e) {
      console.error(e);
    }
  };

  return (
    <div className="min-h-screen bg-slate-950 flex h-screen overflow-hidden text-slate-200 font-sans">
      {/* Side Bar */}
      <aside className="w-16 lg:w-64 border-r border-slate-800 bg-slate-900 flex flex-col items-center lg:items-stretch transition-all duration-300">
        <div className="p-4 lg:p-8 border-b border-slate-800 flex items-center gap-3">
          <div className="w-10 h-10 bg-blue-600 rounded-xl flex items-center justify-center shrink-0 shadow-lg shadow-blue-500/20">
            <Shield className="w-6 h-6 text-white" />
          </div>
          <div className="hidden lg:block">
            <h1 className="text-sm font-black uppercase tracking-tighter italic">CrisisShieldStaff</h1>
            <p className="text-[8px] text-slate-500 font-bold uppercase tracking-widest mt-0.5">Tactical Interface</p>
          </div>
        </div>

        <nav className="flex-1 p-4 lg:p-6 space-y-2">
          <div className="bg-slate-800 text-white p-3 lg:p-4 rounded-2xl border border-slate-700 flex items-center gap-3">
            <Activity className="w-5 h-5 text-blue-400" />
            <span className="hidden lg:block text-xs font-bold uppercase tracking-widest">Ops Monitor</span>
          </div>
          <div className="p-3 lg:p-4 rounded-2xl text-slate-500 flex items-center gap-3 hover:bg-slate-800 transition-all cursor-pointer" onClick={analyzeCam}>
            <Camera className="w-5 h-5" />
            <span className="hidden lg:block text-xs font-bold uppercase tracking-widest">Surveillance</span>
          </div>
          <div className="p-3 lg:p-4 rounded-2xl text-slate-500 flex items-center gap-3 hover:bg-slate-800 transition-all cursor-pointer">
            <Users className="w-5 h-5" />
            <span className="hidden lg:block text-xs font-bold uppercase tracking-widest">Personnel</span>
          </div>
        </nav>

        <div className="p-4 lg:p-6 border-t border-slate-800">
          <button 
            onClick={onLogout}
            className="w-full flex items-center justify-center lg:justify-start gap-3 text-slate-500 hover:text-red-400 transition-colors p-2"
          >
            <LogOut className="w-5 h-5" />
            <span className="hidden lg:block text-xs font-bold uppercase tracking-widest">Sign Off</span>
          </button>
        </div>
      </aside>

      {/* Main Content Area */}
      <main className="flex-1 flex flex-col bg-slate-950 overflow-hidden relative">
        <div className="absolute inset-0 opacity-5 pointer-events-none bg-[url('https://www.transparenttextures.com/patterns/carbon-fibre.png')]"></div>
        
        {/* Top Operational Status */}
        <header className="h-20 border-b border-slate-800 bg-slate-900/50 backdrop-blur-xl px-8 flex items-center justify-between relative z-10">
          <div className="flex items-center gap-8">
            <div>
              <p className="text-[10px] font-black font-mono text-slate-500 uppercase tracking-widest mb-1 leading-none">Command Site</p>
              <h2 className="text-lg font-black text-white uppercase tracking-tight italic">{hotel?.name || "Global Node"}</h2>
            </div>
            <div className="h-8 w-px bg-slate-800 hidden md:block"></div>
            <div className="hidden md:flex items-center gap-6">
              <div className="flex flex-col">
                <span className="text-[10px] font-black font-mono text-slate-500 uppercase tracking-widest">Status</span>
                <span className="text-xs font-black text-emerald-500 uppercase flex items-center gap-1.5">
                  <span className="w-1.5 h-1.5 bg-emerald-500 rounded-full animate-pulse"></span> SYSTEM NOMINAL
                </span>
              </div>
              <div className="flex flex-col">
                <span className="text-[10px] font-black font-mono text-slate-500 uppercase tracking-widest">Uptime</span>
                <span className="text-xs font-black text-slate-300 uppercase">99.9% SECURE</span>
              </div>
            </div>
          </div>
          
          <div className="flex items-center gap-4">
             <div className="hidden xl:flex items-center bg-slate-950 border border-slate-800 px-4 py-2 rounded-xl text-[10px] font-mono font-bold text-slate-500 gap-4">
               <span>LAT: 12.97</span>
               <span>LNG: 77.59</span>
               <span>{new Date().toLocaleTimeString()}</span>
             </div>
             <button className="p-3 bg-slate-800 text-slate-400 rounded-xl hover:text-white transition-all border border-slate-700">
               <Bell className="w-5 h-5" />
             </button>
          </div>
        </header>

        <div className="flex-1 flex p-8 gap-8 overflow-hidden">
          {/* Middle Pane - Alerts & Trigger */}
          <div className="flex-1 flex flex-col gap-8 overflow-y-auto">
            {/* Deploy Protocol Section */}
            <section className="bg-slate-900 border border-slate-800 rounded-[40px] p-8 shadow-2xl relative overflow-hidden shrink-0">
               <div className="absolute top-0 right-0 w-64 h-64 bg-red-600/10 rounded-full blur-[100px] -mr-32 -mt-32"></div>
               <h3 className="text-xs font-black text-red-500 uppercase tracking-[0.3em] mb-8 flex items-center gap-3 italic">
                 <AlertTriangle className="w-4 h-4" /> Active Crisis Protocol
               </h3>
               
               <div className="grid grid-cols-2 sm:grid-cols-4 gap-4 mb-8">
                 {(["fire", "gas", "medical", "other"] as const).map(t => (
                   <button 
                     key={t}
                     onClick={() => setNewAlertType(t)}
                     className={`p-6 rounded-[24px] border-2 transition-all flex flex-col items-center gap-3 ${
                       newAlertType === t 
                        ? "bg-red-600 border-red-500 text-white shadow-xl shadow-red-600/30 status-glow-red scale-105" 
                        : "bg-slate-950 border-slate-800 text-slate-500 hover:border-slate-700 hover:bg-slate-900"
                     }`}
                   >
                     {t === 'fire' && <Flame className="w-8 h-8" />}
                     {t === 'gas' && <Wind className="w-8 h-8" />}
                     {t === 'medical' && <Activity className="w-8 h-8" />}
                     {t === 'other' && <AlertTriangle className="w-8 h-8" />}
                     <span className="text-[10px] font-black uppercase tracking-widest">{t}</span>
                   </button>
                 ))}
               </div>

               <button 
                 onClick={triggerAlert}
                 disabled={isAlerting}
                 className={`w-full py-6 rounded-[24px] font-black text-xs uppercase tracking-[0.4em] transition-all relative overflow-hidden ${
                   isAlerting ? "bg-slate-800 text-slate-500" : "bg-white text-slate-950 hover:scale-[1.02] active:scale-95 emergency-pulse"
                 }`}
               >
                 {isAlerting ? "INITIALIZING UPLINK..." : "INITIATE EMERGENCY BROADCAST"}
               </button>
            </section>

            {/* Live Alerts Queue */}
            <section className="flex-1 min-h-0 flex flex-col">
              <div className="flex items-center justify-between mb-6">
                <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.3em]">Live Threat Log</h3>
                <span className="px-2 py-1 bg-red-600/20 text-red-400 text-[8px] font-black border border-red-500/30 rounded uppercase tracking-widest">Real-time Feed</span>
              </div>
              
              <div className="flex-1 overflow-y-auto pr-2 space-y-4">
                {activeAlerts.length === 0 ? (
                  <div className="h-full border-2 border-dashed border-slate-800 rounded-[32px] flex items-center justify-center text-slate-700 italic text-sm">
                    No active threats detected. Monitoring static...
                  </div>
                ) : (
                  activeAlerts.map(alert => (
                    <div key={alert.id} className="bg-slate-900 border border-slate-800 p-6 rounded-[32px] flex items-center justify-between group hover:border-red-500/50 transition-all">
                       <div className="flex items-center gap-6">
                          <div className={`w-14 h-14 rounded-2xl flex items-center justify-center bg-red-600/10 border border-red-500/30 text-red-500 status-glow-red`}>
                             {alert.type === 'fire' ? <Flame className="w-7 h-7" /> : <AlertTriangle className="w-7 h-7" /> }
                          </div>
                          <div>
                             <h4 className="text-lg font-black text-white uppercase tracking-tight">{alert.type} Incident</h4>
                             <p className="text-xs text-slate-500 max-w-sm line-clamp-1">{alert.description}</p>
                             <div className="flex gap-4 mt-2">
                                <span className="text-[10px] font-black text-slate-400 uppercase tracking-widest bg-slate-950 px-2 py-0.5 rounded">FLOOR {alert.location.floor}</span>
                                <span className="text-[10px] font-black text-red-400 uppercase tracking-widest bg-red-900/20 px-2 py-0.5 rounded">{alert.severity}</span>
                             </div>
                          </div>
                       </div>
                       <button 
                        onClick={() => resolveAlert(alert.id)}
                        className="p-4 bg-slate-950 text-emerald-500 rounded-2xl hover:bg-emerald-500/10 transition-all border border-slate-800"
                        title="Resolve Alert"
                       >
                         <CheckCircle className="w-5 h-5" />
                       </button>
                    </div>
                  ))
                )}
              </div>
            </section>
          </div>

          {/* Right Pane - System Stats & Map */}
          <div className="w-96 hidden xl:flex flex-col gap-8 overflow-y-auto">
             <div className="bg-slate-900 border border-slate-800 rounded-[40px] p-8 flex flex-col gap-6">
               <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em]">Wing Alpha Sensors</h3>
               {[
                 { label: "Smoke Density", value: "0.2 ppm", status: "NOMINAL" },
                 { label: "Ambient Temp", value: "24°C", status: "NOMINAL" },
                 { label: "Co2 Levels", value: "400 ppm", status: "NOMINAL" },
                 { label: "O2 Saturation", value: "21%", status: "NOMINAL" },
               ].map(stat => (
                 <div key={stat.label} className="bg-slate-950 border border-slate-800/50 p-4 rounded-2xl flex items-center justify-between">
                    <div>
                       <p className="text-[10px] font-bold text-slate-500 uppercase mb-1">{stat.label}</p>
                       <p className="text-sm font-black text-white">{stat.value}</p>
                    </div>
                    <span className="text-[8px] font-black text-emerald-500">{stat.status}</span>
                 </div>
               ))}
             </div>

             <div className="flex-1 bg-slate-900 border border-slate-800 rounded-[40px] p-8 flex flex-col">
                <h3 className="text-[10px] font-black text-slate-500 uppercase tracking-[0.2em] mb-6">Master Deck Map</h3>
                <div className="flex-1 bg-slate-950 rounded-[24px] border border-slate-800 relative overflow-hidden flex items-center justify-center group cursor-crosshair">
                   <div className="absolute inset-0 opacity-10 bg-[radial-gradient(#ffffff_1px,transparent_1px)] [background-size:20px_20px]"></div>
                   <MapIcon className="w-12 h-12 text-slate-800 group-hover:scale-110 transition-transform duration-500" />
                   <div className="absolute top-4 left-4 p-2 bg-slate-900 border border-slate-800 rounded text-[8px] font-mono text-slate-500 tracking-widest uppercase">SECTION 02-B OVERLAY</div>
                </div>
             </div>
          </div>
        </div>

        {/* Global Footer Terminal */}
        <footer className="h-10 border-t border-slate-800 bg-slate-950/80 backdrop-blur-md flex items-center justify-between px-8 text-[9px] font-mono font-bold uppercase tracking-[0.3em] text-slate-600">
           <div className="flex gap-8">
             <span>OPS-LAYER: 7</span>
             <span>CLIENT: AIS-NODE-C4</span>
             <span className="text-slate-800 tracking-tighter">||||||||||||||||||||||||||||||||||||||||||||||</span>
           </div>
           <div>AUTHORIZED ACCESS ONLY - MONITORING ACTIVE</div>
        </footer>
      </main>
    </div>
  );
}


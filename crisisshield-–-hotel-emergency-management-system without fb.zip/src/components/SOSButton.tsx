import { useState } from "react";
import { Shield, AlertTriangle } from "lucide-react";
import { motion, AnimatePresence } from "motion/react";
import SOSModal from "./SOSModal";
import { EmergencyType } from "../types";
import { api } from "../services/api";

interface SOSButtonProps {
  hotelId: string;
  userUid: string;
}

export default function SOSButton({ hotelId, userUid }: SOSButtonProps) {
  const [pressed, setPressed] = useState(false);
  const [loading, setLoading] = useState(false);
  const [success, setSuccess] = useState(false);
  const [showModal, setShowModal] = useState(false);

  const handleSOSSelect = async (type: EmergencyType) => {
    setLoading(true);
    try {
      const location = { lat: 12.9716, lng: 77.5946, room: "402", floor: 4 };

      await api.alerts.create({
        hotelId,
        type,
        severity: "critical",
        status: "active",
        location,
        description: "MANUAL SOS TRIGGERED BY GUEST",
        reporterId: userUid,
        role: "guest"
      });

      setSuccess(true);
      setShowModal(false);
      setTimeout(() => setSuccess(false), 5000);
    } catch (error) {
      console.error("SOS Trigger Error:", error);
      alert("Failed to send SOS. Please check connection.");
    } finally {
      setLoading(false);
      setPressed(false);
    }
  };

  return (
    <div className="flex flex-col items-center">
      <AnimatePresence>
        {!success ? (
          <motion.div
            initial={{ scale: 1 }}
            animate={pressed ? { scale: 0.95 } : { scale: 1 }}
            className="relative"
          >
            <div className={`absolute -inset-4 bg-red-500/20 rounded-full blur-xl animate-pulse ${pressed ? 'bg-red-600/40' : ''}`}></div>
            <button
              onMouseDown={() => setPressed(true)}
              onMouseUp={() => {
                setPressed(false);
                setShowModal(true);
              }}
              onTouchStart={() => setPressed(true)}
              onTouchEnd={() => {
                setPressed(false);
                setShowModal(true);
              }}
              className={`relative z-10 w-32 h-32 rounded-full flex flex-col items-center justify-center transition-all ${
                pressed ? "bg-red-700 scale-95" : "bg-red-600 shadow-lg shadow-red-500/50"
              } text-white`}
            >
              <AlertTriangle className="w-10 h-10 mb-1" />
              <span className="font-bold tracking-tighter text-lg leading-none">SOS</span>
            </button>
          </motion.div>
        ) : (
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            animate={{ opacity: 1, y: 0 }}
            exit={{ opacity: 0 }}
            className="bg-green-600 text-white p-4 rounded-2xl flex items-center gap-3 shadow-lg shadow-green-500/30"
          >
            <div className="w-8 h-8 rounded-full bg-white/20 flex items-center justify-center">
              <Shield className="w-4 h-4" />
            </div>
            <div>
              <p className="font-bold text-sm">Help is on the way</p>
              <p className="text-[10px] opacity-80 uppercase tracking-widest">Signal transmitted via satellite/mesh</p>
            </div>
          </motion.div>
        )}
      </AnimatePresence>
      <p className="mt-6 text-slate-400 text-xs font-medium uppercase tracking-[0.2em]">Press and release for emergency aid</p>

      <SOSModal 
        isOpen={showModal} 
        onClose={() => setShowModal(false)} 
        onSelect={handleSOSSelect}
        isLoading={loading}
      />
    </div>
  );
}

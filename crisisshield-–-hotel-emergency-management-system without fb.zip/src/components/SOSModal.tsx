import { motion, AnimatePresence } from "motion/react";
import { X, Flame, HeartPulse, ShieldAlert, CircleDot } from "lucide-react";
import { EmergencyType } from "../types";

interface SOSModalProps {
  isOpen: boolean;
  onClose: () => void;
  onSelect: (type: EmergencyType) => void;
  isLoading: boolean;
}

export default function SOSModal({ isOpen, onClose, onSelect, isLoading }: SOSModalProps) {
  const options: { type: EmergencyType; label: string; icon: any; color: string }[] = [
    { type: "fire", label: "FIRE", icon: Flame, color: "text-orange-500 bg-orange-500/10 border-orange-500/30" },
    { type: "medical", label: "MEDICAL", icon: HeartPulse, color: "text-red-500 bg-red-500/10 border-red-500/30" },
    { type: "security", label: "SECURITY", icon: ShieldAlert, color: "text-blue-500 bg-blue-500/10 border-blue-500/30" },
    { type: "other", label: "OTHER", icon: CircleDot, color: "text-slate-400 bg-slate-400/10 border-slate-400/30" },
  ];

  return (
    <AnimatePresence>
      {isOpen && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <motion.div
            initial={{ opacity: 0 }}
            animate={{ opacity: 1 }}
            exit={{ opacity: 0 }}
            onClick={onClose}
            className="absolute inset-0 bg-slate-950/80 backdrop-blur-sm"
          />
          
          <motion.div
            initial={{ scale: 0.9, opacity: 0, y: 20 }}
            animate={{ scale: 1, opacity: 1, y: 0 }}
            exit={{ scale: 0.9, opacity: 0, y: 20 }}
            className="relative w-full max-w-md bg-slate-900 border border-slate-800 rounded-[40px] shadow-2xl overflow-hidden"
          >
            <div className="p-8">
              <button
                onClick={onClose}
                className="absolute top-6 right-6 p-2 rounded-full hover:bg-slate-800 text-slate-500 transition-colors"
              >
                <X className="w-5 h-5" />
              </button>

              <div className="text-center mb-8">
                <h2 className="text-xl font-black text-white uppercase tracking-tight mb-2">Select Emergency Type</h2>
                <p className="text-xs text-slate-500 font-bold uppercase tracking-widest">Dispatch will alert staff instantly</p>
              </div>

              <div className="grid grid-cols-2 gap-4">
                {options.map((option) => {
                  const Icon = option.icon;
                  return (
                    <button
                      key={option.type}
                      disabled={isLoading}
                      onClick={() => onSelect(option.type)}
                      className={`group relative flex flex-col items-center justify-center p-8 rounded-3xl border transition-all ${
                        option.color
                      } hover:scale-105 active:scale-95 disabled:opacity-50 disabled:cursor-not-allowed`}
                    >
                      <Icon className="w-10 h-10 mb-3 group-hover:scale-110 transition-transform" />
                      <span className="font-black text-xs uppercase tracking-widest">{option.label}</span>
                    </button>
                  );
                })}
              </div>
            </div>

            {isLoading && (
              <div className="absolute inset-0 bg-slate-900/50 backdrop-blur-[2px] flex items-center justify-center">
                <div className="flex flex-col items-center">
                  <div className="w-12 h-12 border-4 border-red-500 border-t-transparent rounded-full animate-spin mb-4" />
                  <p className="text-[10px] font-black text-white uppercase tracking-[0.2em]">Transmitting SOS...</p>
                </div>
              </div>
            )}
          </motion.div>
        </div>
      )}
    </AnimatePresence>
  );
}

import { useState, useRef, useEffect } from "react";
import { Send, Bot, User, ShieldAlert } from "lucide-react";
import ReactMarkdown from "react-markdown";
import { getChatbotResponse } from "../services/aiService";

interface Message {
  role: "bot" | "user";
  content: string;
}

interface EmergencyChatProps {
  emergencyType: string;
}

export default function EmergencyChat({ emergencyType }: EmergencyChatProps) {
  const [messages, setMessages] = useState<Message[]>([
    { role: "bot", content: "I am CrisisShield AI. I can guide you to safety. What do you see?" }
  ]);
  const [input, setInput] = useState("");
  const [loading, setLoading] = useState(false);
  const scrollRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    if (scrollRef.current) {
      scrollRef.current.scrollTop = scrollRef.current.scrollHeight;
    }
  }, [messages]);

  const handleSend = async () => {
    if (!input.trim() || loading) return;

    const userMsg = input.trim();
    setInput("");
    setMessages(prev => [...prev, { role: "user", content: userMsg }]);
    setLoading(true);

    try {
      const reply = await getChatbotResponse(userMsg, emergencyType, { platform: "web", network: "online" });
      setMessages(prev => [...prev, { role: "bot", content: reply }]);
    } catch (error) {
      // Offline fallback
      setMessages(prev => [...prev, { 
        role: "bot", 
        content: "Network issue detected. Switching to local safety protocol: **Stay low, follow exit signs, and wait for staff.**" 
      }]);
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="flex flex-col h-[400px] glass-morphism rounded-3xl overflow-hidden border-slate-200 shadow-2xl">
      <div className="bg-slate-900 p-4 border-b border-slate-800 flex items-center justify-between">
        <div className="flex items-center gap-3">
          <div className="w-8 h-8 rounded-lg bg-blue-600 flex items-center justify-center">
            <Bot className="w-5 h-5 text-white" />
          </div>
          <div>
            <h3 className="text-white text-sm font-bold">CrisisShield AI</h3>
            <div className="flex items-center gap-1">
              <div className="w-1.5 h-1.5 bg-green-500 rounded-full animate-pulse"></div>
              <p className="text-[10px] text-slate-400 font-medium uppercase tracking-widest">Active Safety Protocol</p>
            </div>
          </div>
        </div>
        {emergencyType !== "none" && (
          <div className="bg-red-500/20 px-3 py-1 rounded-full border border-red-500/30 flex items-center gap-2">
            <ShieldAlert className="w-3 h-3 text-red-500" />
            <span className="text-red-500 text-[10px] font-bold uppercase">{emergencyType} MODE</span>
          </div>
        )}
      </div>

      <div ref={scrollRef} className="flex-1 overflow-y-auto p-4 space-y-4 bg-slate-50/50">
        {messages.map((msg, i) => (
          <div key={i} className={`flex ${msg.role === "user" ? "justify-end" : "justify-start"}`}>
            <div className={`max-w-[85%] p-3 rounded-2xl text-sm shadow-sm ${
              msg.role === "user" 
                ? "bg-slate-900 text-white rounded-br-none" 
                : "bg-white text-slate-800 border border-slate-200 rounded-bl-none"
            }`}>
              <div className="markdown-body">
                <ReactMarkdown>{msg.content}</ReactMarkdown>
              </div>
            </div>
          </div>
        ))}
        {loading && (
          <div className="flex justify-start">
            <div className="bg-white border border-slate-200 p-3 rounded-2xl rounded-bl-none shadow-sm flex gap-1">
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce"></div>
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.2s]"></div>
              <div className="w-1.5 h-1.5 bg-slate-400 rounded-full animate-bounce [animation-delay:0.4s]"></div>
            </div>
          </div>
        )}
      </div>

      <div className="p-3 bg-white border-t border-slate-100 flex gap-2">
        <input
          type="text"
          value={input}
          onChange={e => setInput(e.target.value)}
          onKeyDown={e => e.key === "Enter" && handleSend()}
          placeholder="Ask for guidance or report status..."
          className="flex-1 bg-slate-50 text-slate-800 text-sm p-3 rounded-xl focus:outline-none focus:ring-2 focus:ring-blue-500/20"
        />
        <button
          onClick={handleSend}
          disabled={loading}
          className="bg-blue-600 hover:bg-blue-700 text-white p-3 rounded-xl transition-all active:scale-95 disabled:bg-slate-300"
        >
          <Send className="w-4 h-4" />
        </button>
      </div>
    </div>
  );
}

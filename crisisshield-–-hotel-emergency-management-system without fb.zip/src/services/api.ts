import { UserProfile, Alert, Hotel } from "../types";

const API_BASE = "/api";

async function request<T>(path: string, options?: RequestInit): Promise<T> {
  const res = await fetch(`${API_BASE}${path}`, {
    ...options,
    headers: {
      "Content-Type": "application/json",
      ...options?.headers,
    },
  });
  if (!res.ok) {
    const error = await res.json().catch(() => ({ message: "Unknown error" }));
    throw new Error(error.message || "Request failed");
  }
  return res.json();
}

export const api = {
  auth: {
    login: (credentials: any) => request<UserProfile>("/auth/login", { method: "POST", body: JSON.stringify(credentials) }),
    register: (data: any) => request<UserProfile>("/auth/register", { method: "POST", body: JSON.stringify(data) }),
  },
  users: {
    getProfile: (uid: string) => request<UserProfile>(`/users/profile/${uid}`),
    listPending: () => request<UserProfile[]>("/users/pending"),
    approve: (uid: string) => request<any>(`/users/approve/${uid}`, { method: "POST" }),
    reject: (uid: string) => request<any>(`/users/reject/${uid}`, { method: "POST" }),
  },
  hotels: {
    list: () => request<Hotel[]>("/hotels"),
    get: (id: string) => request<Hotel | null>(`/hotels/${id}`),
    create: (data: any) => request<Hotel>("/hotels", { method: "POST", body: JSON.stringify(data) }),
  },
  alerts: {
    list: (params: { hotelId?: string; status?: string }) => {
      const qs = new URLSearchParams(params as any).toString();
      return request<Alert[]>(`/alerts?${qs}`);
    },
    create: (data: any) => request<Alert>("/alerts", { method: "POST", body: JSON.stringify(data) }),
    update: (id: string, data: any) => request<Alert>(`/alerts/${id}`, { method: "PATCH", body: JSON.stringify(data) }),
  }
};

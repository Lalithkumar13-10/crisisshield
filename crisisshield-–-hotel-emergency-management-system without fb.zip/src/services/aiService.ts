import { GoogleGenAI } from "@google/genai";

const ai = new GoogleGenAI({ apiKey: process.env.GEMINI_API_KEY || "" });

export async function analyzeCameraData(cameraData: any, hotelId: string) {
  const prompt = `
    Analyze the following hotel camera data for emergencies:
    Data: ${JSON.stringify(cameraData)}
    Hotel: ${hotelId}
    
    Detect:
    1. Human movement (Safe/Abnormal)
    2. Crowd density (Low/High/Dangerous)
    3. Blocked exits (Yes/No)
    
    Return a raw JSON object string with fields: 'status', 'density', 'blockedExits', and 'evacuationPathRecommendation'.
    Do not include markdown formatting or backticks.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [{ parts: [{ text: prompt }] }],
  });

  const text = response.text || "{}";
  // Attempt to parse cleanup if model still returns markdown
  const cleanJson = text.replace(/```json|```/g, "").trim();
  return JSON.parse(cleanJson);
}

export async function getChatbotResponse(message: string, emergencyType: string, context: any) {
  const prompt = `
    You are CrisisShield AI, an emergency guidance assistant.
    The current emergency type is: ${emergencyType}.
    User context (location, role): ${JSON.stringify(context)}.
    User Message: "${message}"
    
    Provide concise, life-saving instructions. 
    If smoke is present, tell them to stay low. 
    If fire, suggest stairs over elevators.
    Be calm but urgent.
  `;

  const response = await ai.models.generateContent({
    model: "gemini-3-flash-preview",
    contents: [{ parts: [{ text: prompt }] }],
  });

  return response.text || "I am currently processing your request. Please follow exit signs immediately.";
}

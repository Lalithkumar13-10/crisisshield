export type UserRole = "guest" | "staff" | "admin";

export interface UserProfile {
  uid: string;
  email: string;
  role: UserRole;
  hotelId: string;
  name: string;
  isApproved: boolean;
  status: "pending" | "approved" | "rejected";
}

export interface Hotel {
  id: string;
  name: string;
  location: {
    lat: number;
    lng: number;
  };
  address: string;
}

export type EmergencyType = "fire" | "smoke" | "gas" | "medical" | "security" | "none" | "other";

export interface Alert {
  id: string;
  hotelId: string;
  type: EmergencyType;
  severity: "low" | "medium" | "high" | "critical";
  status: "active" | "resolved";
  location: {
    lat: number;
    lng: number;
    room?: string;
    floor?: number;
  };
  timestamp: any;
  description: string;
  reporterId: string;
}

export interface SensorLog {
  id: string;
  hotelId: string;
  sensorType: "smoke" | "heat" | "gas";
  value: number;
  unit: string;
  timestamp: any;
  status: "normal" | "alert";
}

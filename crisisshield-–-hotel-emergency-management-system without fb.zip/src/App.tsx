/**
 * @license
 * SPDX-License-Identifier: Apache-2.0
 */

import React, { useState, useEffect } from "react";
import { BrowserRouter as Router, Routes, Route, Navigate } from "react-router-dom";
import { UserProfile } from "./types";
import { Lock } from "lucide-react";
import { api } from "./services/api";

// Lazy load components once they are created
const Login = React.lazy(() => import("./pages/Login"));
const GuestDashboard = React.lazy(() => import("./pages/GuestDashboard"));
const StaffDashboard = React.lazy(() => import("./pages/StaffDashboard"));
const AdminDashboard = React.lazy(() => import("./pages/AdminDashboard"));

export default function App() {
  const [user, setUser] = useState<UserProfile | null>(null);
  const [loading, setLoading] = useState(true);

  useEffect(() => {
    const checkAuth = async () => {
      const uid = localStorage.getItem("cs_uid");
      if (uid) {
        try {
          const profile = await api.users.getProfile(uid);
          setUser(profile);
        } catch (err) {
          console.error("Auth sync error:", err);
          localStorage.removeItem("cs_uid");
          setUser(null);
        }
      }
      setLoading(false);
    };

    checkAuth();
    
    // Polling for status updates (e.g. approval)
    const interval = setInterval(() => {
      const uid = localStorage.getItem("cs_uid");
      if (uid) {
        api.users.getProfile(uid)
          .then(profile => {
            setUser(profile);
          })
          .catch(() => {
            // If user deleted or error, maybe log out? 
            // For now just keep trying.
          });
      }
    }, 5000);

    return () => clearInterval(interval);
  }, []);

  const handleSignOut = () => {
    localStorage.removeItem("cs_uid");
    setUser(null);
  };

  if (loading) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-slate-900 text-white">
        <div className="flex flex-col items-center gap-4">
          <div className="w-12 h-12 border-4 border-blue-500 border-t-transparent rounded-full animate-spin"></div>
          <p className="font-mono text-sm tracking-widest uppercase">Initializing CrisisShield...</p>
        </div>
      </div>
    );
  }

  if (user && !user.isApproved) {
    return (
      <div className="h-screen w-full flex items-center justify-center bg-slate-950 text-white p-6 relative overflow-hidden">
        {/* Background Elements */}
        <div className="absolute top-0 left-0 w-full h-full opacity-10 pointer-events-none">
          <div className="absolute top-1/4 left-1/4 w-[500px] h-[500px] bg-amber-900 rounded-full blur-[160px]"></div>
        </div>

        <div className="max-w-md w-full bg-slate-900/40 backdrop-blur-3xl p-10 rounded-[32px] text-center border border-amber-500/20 shadow-2xl relative z-10">
          <div className="w-20 h-20 bg-amber-500/10 border border-amber-500/30 rounded-3xl flex items-center justify-center mx-auto mb-6 shadow-xl shadow-amber-500/10">
            <Lock className="w-10 h-10 text-amber-500" />
          </div>
          
          <div className="mb-8">
            <h1 className="text-2xl font-black uppercase tracking-tighter mb-2 text-amber-500">Authorization Pending</h1>
            <div className="inline-flex items-center gap-2 px-3 py-1 bg-amber-500/10 border border-amber-500/30 rounded-full mb-4">
              <span className="w-1.5 h-1.5 bg-amber-500 rounded-full animate-pulse"></span>
              <span className="text-[10px] font-black uppercase tracking-widest text-amber-500">Clearance Level: PENDING</span>
            </div>
            <p className="text-slate-400 text-sm leading-relaxed">
              Your request for <span className="text-white font-bold uppercase tracking-tight">{user.role}</span> access has been logged in the CrisisShield mainframe.
            </p>
          </div>

          <div className="bg-slate-950/50 border border-slate-800 p-6 rounded-2xl text-left mb-8 space-y-4">
            <div className="flex justify-between items-center text-[10px] font-mono uppercase tracking-widest text-slate-500">
              <span>Terminal Node</span>
              <span className="text-slate-300">CS-77-ALPHA</span>
            </div>
            <div className="flex justify-between items-center text-[10px] font-mono uppercase tracking-widest text-slate-500">
              <span>Request ID</span>
              <span className="text-slate-300 font-bold">{user.uid.slice(0, 8).toUpperCase()}</span>
            </div>
            <div className="h-px bg-slate-800 w-full"></div>
            <p className="text-[10px] text-slate-500 font-mono leading-normal italic">
              "Protocol 04 strictly prohibits unauthorized access to Safety Operations during active mesh synchronization. Wait for an Admin to verify your operational credentials."
            </p>
          </div>

          <div className="grid grid-cols-1 gap-3">
            <div className="w-full py-4 bg-slate-900 border border-slate-800 rounded-2xl flex items-center justify-center gap-3">
               <div className="w-4 h-4 border-2 border-amber-500/30 border-t-amber-500 rounded-full animate-spin"></div>
               <span className="text-[10px] font-black uppercase tracking-widest text-slate-300">Awaiting Admin Signal</span>
            </div>
            <button 
              onClick={handleSignOut}
              className="w-full py-4 bg-slate-800 hover:bg-slate-700 border border-slate-700 rounded-2xl text-[10px] font-black uppercase tracking-widest transition-all active:scale-95"
            >
              Abort & Return to Login
            </button>
          </div>
          
          <p className="mt-8 text-[9px] text-slate-600 font-mono uppercase tracking-widest leading-relaxed">
            SYSTEM VERSION: 9.2.14-STABLE // ENCRYPTION: AES-256-GCM
          </p>
        </div>
      </div>
    );
  }

  return (
    <Router>
      <React.Suspense fallback={<div>Loading...</div>}>
        <Routes>
          <Route 
            path="/login" 
            element={user ? <Navigate to="/" /> : <Login />} 
          />
          <Route 
            path="/" 
            element={
              !user ? (
                <Navigate to="/login" />
              ) : user.role === "admin" ? (
                <AdminDashboard user={user} onLogout={handleSignOut} />
              ) : user.role === "staff" ? (
                <StaffDashboard user={user} onLogout={handleSignOut} />
              ) : (
                <GuestDashboard user={user} onLogout={handleSignOut} />
              )
            } 
          />
        </Routes>
      </React.Suspense>
    </Router>
  );
}

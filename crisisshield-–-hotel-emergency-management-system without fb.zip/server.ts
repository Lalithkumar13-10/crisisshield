import express from "express";
import { createServer as createViteServer } from "vite";
import path from "path";
import { fileURLToPath } from "url";
import fs from "fs";
import { v4 as uuidv4 } from "uuid";

const __filename = fileURLToPath(import.meta.url);
const __dirname = path.dirname(__filename);

// Simple JSON Database
const DB_PATH = path.join(process.cwd(), "db.json");

const initialData = {
  users: [],
  hotels: [
    {
      id: "hotel-1",
      name: "CrisisShield Central Hub",
      address: "Global Node 01",
      location: { lat: 12.9716, lng: 77.5946 }
    }
  ],
  alerts: []
};

function loadDB() {
  if (!fs.existsSync(DB_PATH)) {
    fs.writeFileSync(DB_PATH, JSON.stringify(initialData, null, 2));
    return initialData;
  }
  return JSON.parse(fs.readFileSync(DB_PATH, "utf-8"));
}

function saveDB(data) {
  fs.writeFileSync(DB_PATH, JSON.stringify(data, null, 2));
}

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json());

  // --- API ROUTES ---

  // Auth
  app.post("/api/auth/register", (req, res) => {
    const { email, password, name, role } = req.body;
    const db = loadDB();
    
    if (db.users.find(u => u.email === email)) {
      return res.status(400).json({ message: "Email already in use" });
    }

    const isAdmin = email === "admin@example.com";
    const status = (role === "guest" || isAdmin) ? "approved" : "pending";

    const newUser = {
      uid: uuidv4(),
      email,
      password, // In a real app, hash this!
      name: name || (isAdmin ? "System Admin" : "New User"),
      role: isAdmin ? "admin" : role,
      hotelId: "hotel-1",
      isApproved: status === "approved",
      status,
      createdAt: new Date().toISOString()
    };

    db.users.push(newUser);
    saveDB(db);
    
    const { password: _, ...userWithoutPass } = newUser;
    res.json(userWithoutPass);
  });

  app.post("/api/auth/login", (req, res) => {
    const { email, password } = req.body;
    const db = loadDB();
    const user = db.users.find(u => u.email === email && u.password === password);
    
    if (!user) {
      return res.status(401).json({ message: "Invalid credentials" });
    }

    const { password: _, ...userWithoutPass } = user;
    res.json(userWithoutPass);
  });

  // Users
  app.get("/api/users/profile/:uid", (req, res) => {
    const db = loadDB();
    const user = db.users.find(u => u.uid === req.params.uid);
    if (!user) return res.status(404).json({ message: "User not found" });
    const { password: _, ...userWithoutPass } = user;
    res.json(userWithoutPass);
  });

  app.get("/api/users/pending", (req, res) => {
    const db = loadDB();
    res.json(db.users.filter(u => u.status === "pending"));
  });

  app.post("/api/users/approve/:uid", (req, res) => {
    const db = loadDB();
    const user = db.users.find(u => u.uid === req.params.uid);
    if (user) {
      user.status = "approved";
      user.isApproved = true;
      saveDB(db);
    }
    res.json({ success: true });
  });

  app.post("/api/users/reject/:uid", (req, res) => {
    const db = loadDB();
    const user = db.users.find(u => u.uid === req.params.uid);
    if (user) {
      user.status = "rejected";
      user.isApproved = false;
      saveDB(db);
    }
    res.json({ success: true });
  });

  // Hotels
  app.get("/api/hotels", (req, res) => {
    const db = loadDB();
    res.json(db.hotels);
  });

  app.get("/api/hotels/:id", (req, res) => {
    const db = loadDB();
    const hotel = db.hotels.find(h => h.id === req.params.id);
    res.json(hotel || null);
  });

  app.post("/api/hotels", (req, res) => {
    const { name, address, location } = req.body;
    const db = loadDB();
    const newHotel = { id: uuidv4(), name, address, location };
    db.hotels.push(newHotel);
    saveDB(db);
    res.json(newHotel);
  });

  // Alerts
  app.get("/api/alerts", (req, res) => {
    const { hotelId, status } = req.query;
    const db = loadDB();
    let alerts = db.alerts;
    if (hotelId) alerts = alerts.filter(a => a.hotelId === hotelId);
    if (status) alerts = alerts.filter(a => a.status === status);
    res.json(alerts.sort((a, b) => new Date(b.timestamp).getTime() - new Date(a.timestamp).getTime()));
  });

  app.post("/api/alerts", (req, res) => {
    const db = loadDB();
    const newAlert = {
      id: uuidv4(),
      ...req.body,
      timestamp: new Date().toISOString()
    };
    db.alerts.push(newAlert);
    saveDB(db);
    res.json(newAlert);
  });

  app.patch("/api/alerts/:id", (req, res) => {
    const db = loadDB();
    const alert = db.alerts.find(a => a.id === req.params.id);
    if (alert) {
      Object.assign(alert, req.body);
      if (req.body.status === "resolved") {
        alert.resolvedAt = new Date().toISOString();
      }
      saveDB(db);
    }
    res.json(alert);
  });

  // Vite/SPA middleware
  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), 'dist');
    app.use(express.static(distPath));
    app.get('*', (req, res) => {
      res.sendFile(path.join(distPath, 'index.html'));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`CrisisShield Terminal online at http://localhost:${PORT}`);
  });
}

startServer();

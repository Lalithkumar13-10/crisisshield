# CrisisShield – Hotel Emergency Management System

CrisisShield is a unified safety platform designed to protect hotel guests and staff during emergencies.

## 🚀 Features

- **AI Surveillance:** Real-time camera analysis to detect abnormal movement, crowd density, and blocked exits.
- **Sensor Monitoring:** Simulated detection of fire, smoke, and gas leaks.
- **Manual SOS:** One-tap emergency rescue request with precise location tracking.
- **Smart Evacuation:** Dynamic navigation paths optimized by AI and sensor data.
- **AI Chatbot:** Intelligent guidance ("Panic-Reduced Instructions") powered by Gemini AI.
- **Offline Fallback:** Simulated Bluetooth Mesh communication for device-to-device alerts when internet fails.
- **Multi-Hotel Platform:** Support for multiple properties under a single administrative dashboard.

## 🛠️ Tech Stack

- **Frontend:** React, Vite, Tailwind CSS, Motion, Lucide Icons.
- **Backend:** Node.js, Express, tsx.
- **Database/Auth:** Firebase Firestore & Firebase Auth.
- **AI:** Google Gemini AI (via Google AI SDK).

## 📋 Setup & Deployment

1. **Configure Secrets:**
   - Add `GEMINI_API_KEY` to your secrets (AI Studio Secrets panel).
   - Ensure `APP_URL` is set if using OAuth or self-referential links.

2. **Initialize Firebase:**
   - Run the `set_up_firebase` tool (handled during initial agent turn).
   - Rules are automatically deployed to Firestore.

3. **Development Mode:**
   - Run `npm run dev` to start the Express + Vite server.
   - Access the dashboard at the provided Cloud Run URL.

4. **Production Build:**
   - Run `npm run build` to generate static assets.
   - The server serves these assets from the `dist/` directory.

## 🏨 Role Access

- **Guest:** Access SOS button, AI Chatbot, and evacuation map.
- **Staff:** Manage live incidents, simulate sensor triggers, and resolve alerts.
- **Admin:** Register and manage multiple hotel locations globally.

---
*Safety first. CrisisShield is your eyes and ears in moments that matter.*
